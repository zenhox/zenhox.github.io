#!/bin/sh

aclocal
autoconf
autoheader
automake -a
